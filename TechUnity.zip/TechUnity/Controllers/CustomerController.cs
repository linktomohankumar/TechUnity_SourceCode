﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using TechUnity.BLL;
using TechUnity.Logger;
using TechUnity.Model;

namespace TechUnity.Controllers
{
    [Authorize(Roles = "User")]
    public class CustomerController : Controller
    {
        private TUBLL ObjTUBLL = null;

        public CustomerController()
        {
            ObjTUBLL = new TUBLL();
        }

        public ActionResult Index()
        {
            return View(ObjTUBLL.GetCustomerList(User.Identity.Name));
        }

        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "CustomerId,CustomerName")] Customer customer)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    ObjTUBLL.CreateCustomer(customer, User.Identity.Name);
                    return RedirectToAction("Index");
                }

                return View(customer);
            }
            catch (Exception ex)
            {
                IErrorLogRepo _err = new ErrorLog();
                _err.Log(ex.Message, User.Identity.Name);
                throw ex;
            }
        }

        public ActionResult Edit(int? id)
        {
            try
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Customer customer = ObjTUBLL.GetCustomer(id, User.Identity.Name);
                if (customer == null)
                {
                    return HttpNotFound();
                }
                return View(customer);
            }
            catch (Exception ex)
            {
                IErrorLogRepo _err = new ErrorLog();
                _err.Log(ex.Message, User.Identity.Name);
                throw ex;
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "CustomerId,CustomerName")] Customer customer)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    ObjTUBLL.UpdateCustomer(customer, User.Identity.Name);
                    return RedirectToAction("Index");
                }
                return View(customer);
            }
            catch (Exception ex)
            {
                IErrorLogRepo _err = new ErrorLog();
                _err.Log(ex.Message, User.Identity.Name);
                throw ex;
            }
        }       
    }
}
