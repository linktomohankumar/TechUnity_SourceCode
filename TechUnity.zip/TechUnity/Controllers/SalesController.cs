﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TechUnity.BLL;
using TechUnity.Logger;
using TechUnity.Model;

namespace TechUnity.Controllers
{
    [Authorize(Roles = "User")]
    public class SalesController : Controller
    {
        private TUBLL ObjTUBLL = null;

        public SalesController()
        {
            ObjTUBLL = new TUBLL();
        }

        public ActionResult Index()
        {
            try
            {
                return View(ObjTUBLL.GetSalesOrderList(User.Identity.Name));
            }
            catch (Exception ex)
            {
                IErrorLogRepo _err = new ErrorLog();
                _err.Log(ex.Message, User.Identity.Name);
                throw ex;
            }
        }

        public ActionResult Create()
        {
            this.GetCustomerAndItemList();
            return View();
        }


        [HttpGet]
        public JsonResult GetItemInfo(int _id)
        {
            var _item = ObjTUBLL.GetItem(_id, User.Identity.Name);
            return Json(_item, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult Create(HttpPostedFileBase OrderRefDocs, NewSalesOrder _salesorder)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    byte[] uploadedFile = null;
                    if (OrderRefDocs != null)
                    {
                        uploadedFile = new byte[OrderRefDocs.InputStream.Length];
                        OrderRefDocs.InputStream.Read(uploadedFile, 0, uploadedFile.Length);
                    }

                    ObjTUBLL.CreateSalesOrder(_salesorder, User.Identity.Name, uploadedFile);
                    return RedirectToAction("Index");
                }
                this.GetCustomerAndItemList();
                return View(_salesorder);
            }
            catch (Exception ex)
            {
                IErrorLogRepo _err = new ErrorLog();
                _err.Log(ex.Message, User.Identity.Name);
                throw ex;
            }
        }

        [NonAction]
        private void GetCustomerAndItemList()
        {
            try
            {
                List<SelectListItem> lstSelectList = new List<SelectListItem>();
                SelectListItem _item = new SelectListItem();

                List<Customer> lstCustomer = ObjTUBLL.GetCustomerList(User.Identity.Name);
                lstSelectList.Add(new SelectListItem { Selected = true, Text = "-- Select Customer --", Value = "" });
                foreach (var item in lstCustomer)
                {
                    _item = new SelectListItem();
                    _item.Text = item.CustomerName + "(" + item.CustomerId.ToString() + ")";
                    _item.Value = item.CustomerId.ToString();
                    lstSelectList.Add(_item);
                }
                ViewBag.CustomerList = new SelectList(lstSelectList, "Value", "Text", 0);

                List<Item> lstItem = ObjTUBLL.GetItemList(User.Identity.Name);
                lstSelectList = new List<SelectListItem>();
                lstSelectList.Add(new SelectListItem { Selected = true, Text = "-- Select Item --", Value = "" });
                _item = new SelectListItem();
                foreach (var item in lstItem)
                {
                    _item = new SelectListItem();
                    _item.Text = item.ItemId + "(" + item.ItemName.ToString() + ")";
                    _item.Value = item.ItemId.ToString();
                    lstSelectList.Add(_item);
                }
                ViewBag.ItemList = new SelectList(lstSelectList, "Value", "Text", 0);
            }
            catch (Exception ex)
            {
                IErrorLogRepo _err = new ErrorLog();
                _err.Log(ex.Message, User.Identity.Name);
            }
        }
    }
}