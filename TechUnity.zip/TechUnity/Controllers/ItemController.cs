﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TechUnity.BLL;
using TechUnity.Model;
using TechUnity.Logger;

namespace TechUnity.Controllers
{
    [Authorize(Roles = "User")]
    public class ItemController : Controller
    {
        private TUBLL ObjTUBLL = null;

        public ItemController()
        {
            ObjTUBLL = new TUBLL();
        }

        public ActionResult Index()
        {
            try
            {
                return View(ObjTUBLL.GetItemList(User.Identity.Name));
            }
            catch(Exception ex)
            {
                IErrorLogRepo _err = new ErrorLog();
                _err.Log(ex.Message, User.Identity.Name);
                throw ex;
            }
        }

        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "ItemName,ItemPrice")] Item item)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    ObjTUBLL.CreateItem(item, User.Identity.Name);
                    return RedirectToAction("Index");
                }

                return View(item);
            }
            catch (Exception ex)
            {
                IErrorLogRepo _err = new ErrorLog();
                _err.Log(ex.Message, User.Identity.Name);
                throw ex;
            }
        }
    }
}