﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using TechUnity.BLL;
using TechUnity.Logger;
using TechUnity.Model;

namespace TechUnity.Controllers
{
    public class AccountController : Controller
    {
        private TUBLL ObjTUBLL = null;

        public AccountController()
        {
            ObjTUBLL = new TUBLL();
        }

        [HttpGet]
        public ActionResult Register()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Register(User _user)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (ObjTUBLL.Register(new User
                    {
                        FirstName = _user.FirstName,
                        Email = _user.Email,
                        LastName = _user.LastName,
                        Password = this.GetMD5(_user.Password)
                    }))
                        return RedirectToAction("Login");
                }
                return View();
            }
            catch (Exception ex)
            {
                IErrorLogRepo _err = new ErrorLog();
                _err.Log(ex.Message, User.Identity.Name);
                throw ex;
            }
        }

        public ActionResult Login()
        {
            return View();
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Login(Login login)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var data = ObjTUBLL.Login(login.Email, this.GetMD5(login.Password));
                    if (data != null)
                    {
                        Session["Email"] = data.Email;

                        var authTicket = new FormsAuthenticationTicket(
                            1,
                            data.UserId.ToString(),
                            DateTime.Now,
                            DateTime.Now.AddMinutes(5),
                            false, "User"
                            );

                        string encryptedTicket = FormsAuthentication.Encrypt(authTicket);

                        var authCookie = new HttpCookie(FormsAuthentication.FormsCookieName, encryptedTicket);
                        System.Web.HttpContext.Current.Response.Cookies.Add(authCookie);

                        return RedirectToAction("Index", "Sales");
                    }
                    else
                    {
                        ViewBag.error = "Login failed";
                        return RedirectToAction("Login");
                    }
                }
                return View();
            }
            catch (Exception ex)
            {
                IErrorLogRepo _err = new ErrorLog();
                _err.Log(ex.Message, User.Identity.Name);
                throw ex;
            }
        }

        [NonAction]
        private string GetMD5(string str)
        {
            MD5 md5 = new MD5CryptoServiceProvider();
            byte[] fromData = Encoding.UTF8.GetBytes(str);
            byte[] targetData = md5.ComputeHash(fromData);
            string byte2String = null;

            for (int i = 0; i < targetData.Length; i++)
            {
                byte2String += targetData[i].ToString("x2");

            }
            return byte2String;
        }
    }
}