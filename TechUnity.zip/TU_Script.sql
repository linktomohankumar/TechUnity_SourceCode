CREATE TABLE [dbo].[UserMaster] (
    [UserId]    INT  IDENTITY (1, 1) NOT NULL,
    [FirstName] VARCHAR (50)  NOT NULL,
    [LastName]  VARCHAR (50)  NOT NULL,
    [Email]     NVARCHAR (MAX) NOT NULL,
    [Password]  NVARCHAR (MAX) NOT NULL,
	[CreatedDate] DATETIME NOT NULL,
    CONSTRAINT [PK_UserMaster] PRIMARY KEY CLUSTERED ([UserId] ASC)
);
GO

CREATE TABLE [dbo].[CustomerMaster] (
    [CustId]    INT  IDENTITY (1, 1) NOT NULL,
    [CustName] VARCHAR (50)  NOT NULL,
	[CreatedBy] INT  NOT NULL,
    [CreatedDate] DATETIME NOT NULL,
    CONSTRAINT [PK_CustomerMaster] PRIMARY KEY CLUSTERED ([CustId] ASC),
	FOREIGN KEY ([CreatedBy]) REFERENCES [dbo].[UserMaster] ([UserId])
);
GO

CREATE TABLE [dbo].[ItemMaster] (
    [ItemId]    INT  IDENTITY (1, 1) NOT NULL,
    [ItemName] VARCHAR (50)  NOT NULL,
	[ItemPrice] INT  NOT NULL,
	[CreatedBy] INT  NOT NULL,
    [CreatedDate] DATETIME NOT NULL,
    CONSTRAINT [PK_ItemMaster] PRIMARY KEY CLUSTERED ([ItemId] ASC),
	FOREIGN KEY ([CreatedBy]) REFERENCES [dbo].[UserMaster] ([UserId])
);
GO

CREATE TABLE [dbo].[SalesOrder] (
    [OrderId]    INT  IDENTITY (1, 1) NOT NULL,
	[OrderNo] VARCHAR (50)  NOT NULL,
    [CustId] INT  NOT NULL,
	[OrderDate] DATE  NOT NULL,
	[Address1] VARCHAR (50)  NOT NULL,
	[Address2] VARCHAR (50)  NOT NULL,
	[OrderDocs] VARBINARY  NULL,
	[CreatedBy] INT  NOT NULL,
    [CreatedDate] DATETIME NOT NULL,
    CONSTRAINT [PK_SalesOrder] PRIMARY KEY CLUSTERED ([OrderId] ASC),
	FOREIGN KEY ([CustId]) REFERENCES [dbo].[CustomerMaster] ([CustId]),
	FOREIGN KEY ([CreatedBy]) REFERENCES [dbo].[UserMaster] ([UserId])
);
GO

CREATE TABLE [dbo].[SalesOrderDetails] (
    [DetailId]    INT  IDENTITY (1, 1) NOT NULL,
	[OrderId] INT  NOT NULL,
    [ItemId] INT  NOT NULL,
	[ItemQty] INT  NOT NULL,
    CONSTRAINT [PK_SalesOrderDetails] PRIMARY KEY CLUSTERED ([DetailId] ASC),
	FOREIGN KEY ([OrderId]) REFERENCES [dbo].[SalesOrder] ([OrderId]),
	FOREIGN KEY ([ItemId]) REFERENCES [dbo].[ItemMaster] ([ItemId])
);
GO