﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;
using TechUnity.Model;

namespace TechUnity.DAL
{
    public class TUDAL
    {
        TechUnityEntities _db = null;
        public TUDAL()
        {
            _db = new TechUnityEntities();
        }
        public bool RegisterUser(User _user)
        {
            try
            {
                _db.UserMasters.Add(new UserMaster { FirstName = _user.FirstName, LastName = _user.LastName,
                    Email = _user.Email, Password = _user.Password, CreatedDate = DateTime.Now });
                _db.SaveChanges();
            }
            catch (Exception ex)
            {
                return false;
            }
            return true;
        }
        public UserMaster LoginUser(string email, string password)
        {
            var _user = _db.UserMasters.Where(x => x.Email.Equals(email) && x.Password.Equals(password)).FirstOrDefault();
            return _user;
        }

        public List<CustomerMaster> GetCustomerList(int userId)
        {
            return _db.CustomerMasters.Where(x => x.CreatedBy == userId).ToList();
        }

        public Customer GetCustomer(int? custId,int userId)
        {
            var cust = _db.CustomerMasters.Where(x=>x.CustId == custId && x.CreatedBy == userId).FirstOrDefault();
            return new Customer { CustomerId = cust.CustId, CustomerName = cust.CustName };
        }

        public bool CreateCustomer(Customer _user,int userId)
        {
            try
            {
                _db.CustomerMasters.Add(new CustomerMaster
                {
                    CustName = _user.CustomerName,
                    CreatedBy = userId,
                    CreatedDate = DateTime.Now
                });
                _db.SaveChanges();
            }
            catch (Exception ex)
            {
                return false;
            }
            return true;
        }

        public bool UpdateCustomer(Customer _cust, int userId)
        {
            try
            {
                var item = _db.CustomerMasters.Where(x=>x.CustId == _cust.CustomerId).FirstOrDefault();
                if (item != null)
                {
                    item.CustName = _cust.CustomerName;
                    _db.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                return false;
            }
            return true;
        }

        public List<ItemMaster> GetItemList(int userId)
        {
            return _db.ItemMasters.Where(x => x.CreatedBy == userId).ToList();
        }

        public Item GetItem(int? itemId, int userId)
        {
            var item = _db.ItemMasters.Where(x => x.ItemId == itemId && x.CreatedBy == userId).FirstOrDefault();
            return new Item { ItemId = item.ItemId, ItemName = item.ItemName, ItemPrice = item.ItemPrice };
        }

        public bool CreateItem(Item _item, int userId)
        {
            try
            {
                _db.ItemMasters.Add(new ItemMaster
                {
                    ItemName = _item.ItemName,
                    ItemPrice = _item.ItemPrice,
                    CreatedBy = userId,
                    CreatedDate = DateTime.Now
                });
                _db.SaveChanges();
            }
            catch (Exception ex)
            {
                return false;
            }
            return true;
        }

        public List<SalesOrder> GetSalesOrderList(int userId)
        {
            return _db.SalesOrders.Where(x => x.CreatedBy == userId).ToList();
        }

        public bool CreateSalesOrder(NewSalesOrder _sales, int userId, byte[] orderdocs)
        {
            try
            {
                var _so = _db.SalesOrders.Add(new SalesOrder
                {
                    OrderNo = _sales.OrderNo,
                    OrderDate = _sales.OrderDate,
                    Address1 = _sales.Address1,
                    Address2 = _sales.Address2,
                    CustId  = Convert.ToInt32(_sales.Customer),
                    CreatedBy = userId,
                    CreatedDate = DateTime.Now
                });
                _db.SaveChanges();

                for (int i = 0; i < _sales.ItemId.Count; i++)
                {
                    int ItemId = _sales.ItemId[i];
                    int ItemQty = _sales.ItemQty[i];
                    _db.SalesOrderDetails.Add(new SalesOrderDetail
                    {
                        OrderId = _so.OrderId,
                        ItemId = ItemId,
                        ItemQty = ItemQty
                    });
                    _db.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                return false;
            }
            return true;
        }

    }
}
