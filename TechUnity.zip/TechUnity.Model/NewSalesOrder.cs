﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace TechUnity.Model
{
    public class NewSalesOrder
    {
        [Required]
        public string OrderNo { get; set; }

        [Required]
        public DateTime OrderDate { get; set; }

        [Required]
        public string Customer { get; set; }

        [Required]
        public string Address1 { get; set; }

        [Required]
        public string Address2 { get; set; }

        [Display(Name = "Order Document")]
        [DataType(DataType.Upload)]
        public string OrderRefDocs { get; set; }

        [Required]
        public List<int> ItemId { get; set; }

        [Required]
        public List<int> ItemQty { get; set; }

    }
}
