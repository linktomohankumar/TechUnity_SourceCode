﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TechUnity.Model
{
    public class SalesOrderIndex
    {
        public string OrderNo { get; set; }

        public string OrderDate { get; set; }
        public string Customer { get; set; }

        public int OrderValue { get; set; }

    }
}
