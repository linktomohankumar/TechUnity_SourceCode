﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechUnity.DAL;
using TechUnity.Model;

namespace TechUnity.BLL
{
    public class TUBLL
    {
        TUDAL _dal = null;

        public TUBLL()
        {
            _dal = new TUDAL();
        }
        public bool Register(User user)
        {
            return _dal.RegisterUser(user);
        }

        public User Login(string email, string password)
        {
            var userinfo = _dal.LoginUser(email, password);
            return new User { Email = userinfo.Email, UserId = userinfo.UserId };
        }

        public List<Customer> GetCustomerList(string userId)
        {
            List<CustomerMaster> lstCustomer = _dal.GetCustomerList(Convert.ToInt32(userId));
            return lstCustomer.Select(x => new Customer
            {
                CustomerId = x.CustId,
                CustomerName = x.CustName,
            }).ToList();
        }

        public Customer GetCustomer(int? custId, string userId)
        {
            return _dal.GetCustomer(custId, Convert.ToInt32(userId));
        }

        public bool CreateCustomer(Customer cust, string userId)
        {
            return _dal.CreateCustomer(cust, Convert.ToInt32(userId));
        }

        public bool UpdateCustomer(Customer _cust, string userId)
        {
            return _dal.UpdateCustomer(_cust, Convert.ToInt32(userId));
        }

        public bool CreateItem(Item item, string userId)
        {
            return _dal.CreateItem(item, Convert.ToInt32(userId));
        }

        public Item GetItem(int? itemId, string userId)
        {
            return _dal.GetItem(itemId, Convert.ToInt32(userId));
        }

        public List<Item> GetItemList(string userId)
        {
            List<ItemMaster> lstCustomer = _dal.GetItemList(Convert.ToInt32(userId));
            return lstCustomer.Select(x => new Item
            {
                ItemId = x.ItemId,
                ItemName = x.ItemName,
                ItemPrice = x.ItemPrice
            }).ToList();
        }

        public List<SalesOrderIndex> GetSalesOrderList(string userId)
        {
            List<SalesOrder> lstSales = _dal.GetSalesOrderList(Convert.ToInt32(userId));
            return lstSales.Select(x => new SalesOrderIndex
            {
                OrderNo = x.OrderNo,
                Customer = x.CustomerMaster.CustName,
                OrderDate = x.OrderDate.ToString("MM/dd/yyyy"),
                OrderValue = x.SalesOrderDetails.Sum(y => y.ItemQty * y.ItemMaster.ItemPrice)
            }).ToList();
        }

        public bool CreateSalesOrder(NewSalesOrder _sales, string userId, byte[] orderdocs)
        {
            return _dal.CreateSalesOrder(_sales, Convert.ToInt32(userId), orderdocs);
        }
    }
}
