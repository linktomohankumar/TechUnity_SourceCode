﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TechUnity.Logger
{
    public interface IErrorLogRepo
    {
        void Log(string ErrorMsg, string UserId);
    }
}
