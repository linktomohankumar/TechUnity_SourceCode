﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TechUnity.Logger
{
    public class ErrorLog : IErrorLogRepo
    {
        public void Log(string ErrorMsg, string UserId)
        {
            // Log the error into DB or file.
        }
    }
}
